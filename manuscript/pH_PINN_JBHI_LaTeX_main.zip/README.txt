pH-PINN Cardiac Digital Twin -- LaTeX bundle (IEEE J-BHI)
  main.tex          IEEE submission version: 8 pages (compact "et al." references with DOIs).
  main_fullrefs.tex Identical text, full author lists + DOIs (9 pages) -- used for the preprint.
  figures/          Fig.1 training, Fig.2 ablation, Fig.3 validation, Fig.4 PV loop.
IEEEtran class supplied by IEEE/CTAN. References inline (thebibliography, 22 entries) -- no .bib/.bbl.
